#include <iostream>
#include "CsvFeeder.h"
#include "date/date.h"

uint64_t TimeToUnixMS(std::string ts) {
    std::istringstream in{ts};
    std::chrono::system_clock::time_point tp;
    in >> date::parse("%FT%T", tp);
    const auto timestamp = std::chrono::time_point_cast<std::chrono::milliseconds>(tp).time_since_epoch().count();
    return timestamp;
}

double StrToDouble(std::string str)
{
    if(str.empty() || str == " ")
    {
        return std::numeric_limits<double>::quiet_NaN();
    }
    return std::stod(str);
}


bool ReadNextMsg(std::ifstream& file, Msg& msg) {
    // declare local variables
    std::string line, field;
    int i = 1;
    
    while (i < 2)
    {
        getline(file, line);
        i += 1;
    }

    if (file.eof()) {
        return false;
    }

    // TODO: your implementation to read file and create the next Msg into the variable msg
    std::vector<std::string> row;
    
    // get csv line
    getline(file, line);

    // string stream for line processing
    std::stringstream str(line);

    int j = 0;

    // parse line field values into the row vector
    while (getline(str, field, ','))
    {
        row.push_back(field);

    }

    if (row.size() == 0) {return false;}

    // process individual fields
    TickData tickdata_;
    tickdata_.ContractName = row[0];
    tickdata_.LastUpdateTimeStamp = TimeToUnixMS(row[1]);
    tickdata_.BestBidPrice = StrToDouble(row[4]);
    tickdata_.BestBidAmount = StrToDouble(row[5]);
    tickdata_.BestBidIV = StrToDouble(row[6]);
    tickdata_.BestAskPrice = StrToDouble(row[7]);
    tickdata_.BestAskAmount = StrToDouble(row[8]);
    tickdata_.BestAskIV = StrToDouble(row[9]);
    tickdata_.MarkPrice = StrToDouble(row[10]);
    tickdata_.MarkIV = StrToDouble(row[11]);
    tickdata_.UnderlyingIndex = row[12];
    tickdata_.UnderlyingPrice = StrToDouble(row[13]);
    tickdata_.LastPrice = StrToDouble(row[15]);
    tickdata_.OpenInterest = StrToDouble(row[16]);

    msg.Updates.push_back(tickdata_);
    msg.isSet = true;

    if (row[2] == "snap")
    {
        msg.isSnap = true;
        msg.timestamp = tickdata_.LastUpdateTimeStamp;
    }
    else if (row[2] == "update")
    {
        msg.isSnap = false;
    }
    return true;
}


CsvFeeder::CsvFeeder(const std::string ticker_filename,
                     FeedListener feed_listener,
                     std::chrono::minutes interval,
                     TimerListener timer_listener)
        : ticker_file_(ticker_filename),
          feed_listener_(feed_listener),
          interval_(interval),
          timer_listener_(timer_listener) {
    // initialize member variables with input information, prepare for Step() processing

    ReadNextMsg(ticker_file_, msg_);
    if (msg_.isSet) {
        // initialize interval timer now_ms_
        now_ms_ = msg_.timestamp;
        std::cout << msg_.Updates.size();
    } else {
        throw std::invalid_argument("empty message at initialization");
    }
}

bool CsvFeeder::Step() {
    if (msg_.isSet) {
        // call feed_listener with the loaded Msg
        feed_listener_(msg_);

        // if current message's timestamp is crossing the given interval, call time_listener, change now_ms_ to the next interval cutoff
        if (now_ms_ < msg_.timestamp) {
            timer_listener_(now_ms_);
            now_ms_ += interval_.count();
        }
        // load tick data into Msg
        // if there is no more message from the csv file, return false, otherwise true
        return ReadNextMsg(ticker_file_, msg_);
    }
    return false;
}

CsvFeeder::~CsvFeeder() {
    // release resource allocated in constructor, if any
}
