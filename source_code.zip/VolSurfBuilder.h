#ifndef QF633_CODE_VOLSURFBUILDER_H
#define QF633_CODE_VOLSURFBUILDER_H

#include <map>
#include "Msg.h"
#include "Date.h"

template<class Smile>
class VolSurfBuilder {
public:
    void Process(const Msg& msg);  // process message
    void PrintInfo();
    std::map<datetime_t, std::pair<Smile, double> > FitSmiles();
protected:
    // we want to keep the best level information for all instruments
    // here we use a map from contract name to BestLevelInfo, the key is contract name
    std::map<std::string, TickData> currentSurfaceRaw;
};

template <class Smile>
void VolSurfBuilder<Smile>::Process(const Msg& msg) {
    if (msg.isSnap) {        
        // dump current snapshot
        // create new snapshot from the parameter Msg
        // to avoid error accumulation
        currentSurfaceRaw.clear();
        for (auto &val : msg.Updates)
        {
            currentSurfaceRaw.insert({val.ContractName, val});
        }
    } else {
        // Apply updates to current snapshot
        auto data = msg.Updates.back();
        currentSurfaceRaw.insert({data.ContractName, data});
    }
}

template <class Smile>
void VolSurfBuilder<Smile>::PrintInfo() {
    // TODO: you may print out information about VolSurfBuilder's currentSnapshot to test
    for (auto const &[key, val] : currentSurfaceRaw)
    {
        TickData data = val;

        std::cout << val.ContractName << ","
                    << val.LastUpdateTimeStamp << ","
                    << val.BestBidPrice << ","
                    << val.BestBidAmount << ","
                    << val.BestBidIV << ","
                    << val.BestAskPrice << ","
                    << val.BestAskAmount << ","
                    << val.BestAskIV << ","
                    << val.MarkPrice << ","
                    << val.MarkIV << ","
                    << val.UnderlyingIndex << ","
                    << val.UnderlyingPrice << ","
                    << val.LastPrice << ","
                    << val.OpenInterest << std::endl;
    }
}

template <class Smile>
std::map<datetime_t, std::pair<Smile, double> > VolSurfBuilder<Smile>::FitSmiles() {
    std::map<datetime_t, std::vector<TickData> > tickersByExpiry{};
    // TODO: group the tickers in the current market snapshot by expiry date, and construct tickersByExpiry
    // ...
    
    for (auto const &[key, val] : currentSurfaceRaw)
    {
        TickData data = val;
        if (tickersByExpiry.find(val.LastUpdateTimeStamp) == tickersByExpiry.end())
        {
            std::vector<TickData> tick_;
            tick_.push_back(val);
            tickersByExpiry.insert({val.LastUpdateTimeStamp, tick_});
        }
        else
        {
            std::map<datetime_t, std::vector<TickData>>::iterator itr;
            itr = tickersByExpiry.find(val.LastUpdateTimeStamp);

            if (itr != tickersByExpiry.end())
                itr->second.push_back(val);
        }
    }

    std::map<datetime_t, std::pair<Smile, double> > res{};
    // then create Smile instance for each expiry by calling FitSmile() of the Smile
    for (auto iter = tickersByExpiry.begin(); iter != tickersByExpiry.end(); iter++) {
        std::cout << "tickersByExpirySize: " << tickersByExpiry.size() << std::endl;
        auto sm = Smile::FitSmile(iter->second);  // TODO: you need to implement FitSmile function in CubicSmile
        std::cout << "after fitting"<< std::endl;
        double fittingError = 0;
        // TODO: we need to measure the fitting error here
        res.insert(std::pair<datetime_t, std::pair<Smile, double> >(iter->first,std::pair<Smile, double>(sm, fittingError)));
    }
    return res;
}

#endif //QF633_CODE_VOLSURFBUILDER_H
